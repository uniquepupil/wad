// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";

import {getAuth} from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBoWH9RDZMqO_RZokMEB6YOTfM6yvCOMkE",
  authDomain: "cloud-cd41c.firebaseapp.com",
  projectId: "cloud-cd41c",
  storageBucket: "cloud-cd41c.appspot.com",
  messagingSenderId: "312857365619",
  appId: "1:312857365619:web:3b20f96b54252f7a652e06",
  measurementId: "G-M1B1DS7MWF"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);